import { Link } from "react-router-dom";

function Navbar() {
  return (
    <nav className="bg-black/30 backdrop-blur-md fixed top-0 left-0 w-full px-6 py-4 flex justify-between items-center shadow-lg">
      <Link to="/" className="text-2xl font-bold text-white">
        API Finder
      </Link>
      <div className="flex gap-4">
        <Link to="/" className="text-white hover:text-gray-300 transition">
          Home
        </Link>
        <Link to="/explore" className="text-white hover:text-gray-300 transition">
          Explore
        </Link>
        <Link to="/login" className="text-white hover:text-gray-300 transition">
          Login
        </Link>
      </div>
    </nav>
  );
}

export default Navbar;
