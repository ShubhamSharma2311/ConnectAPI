import { useState } from "react";

interface SearchBarProps {
  setQuery: (query: string) => void; // Accept function as prop
}

const SearchBar: React.FC<SearchBarProps> = ({ setQuery }) => {
  const [input, setInput] = useState("");

  const handleSearch = () => {
    setQuery(input); // Update parent state
  };

  return (
    <div className="mt-20 flex justify-center">
      <input
        type="text"
        placeholder="Search for APIs..."
        className="w-96 px-4 py-2 rounded-lg text-black focus:outline-none shadow-md"
        value={input}
        onChange={(e) => setInput(e.target.value)}
      />
      <button
        onClick={handleSearch}
        className="ml-3 px-6 py-2 rounded-lg bg-gradient-to-r from-purple-500 to-indigo-600 text-white font-semibold shadow-lg transition-all duration-300 transform hover:scale-105 hover:shadow-2xl"
      >
        Search
      </button>
    </div>
  );
};

export default SearchBar;
