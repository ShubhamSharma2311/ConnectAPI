import React from "react";

interface APIcardProps {
  name: string;
  description: string;
  pricing: string;
}

const APIcard: React.FC<APIcardProps> = ({ name, description, pricing }) => {
  return (
    <div className="bg-gradient-to-br from-purple-500 to-blue-500 p-4 rounded-2xl shadow-lg hover:shadow-2xl transform hover:-translate-y-1 transition duration-300">
      <h2 className="text-white text-lg font-bold">{name}</h2>
      <p className="text-gray-200 text-sm mt-2">{description}</p>
      <p className="text-gray-100 text-sm mt-2 font-semibold">{pricing}</p>
      <button className="mt-3 bg-white text-blue-600 font-bold py-1 px-3 rounded-md hover:bg-gray-200 transition">
        View Details
      </button>
    </div>
  );
};

export default APIcard;
