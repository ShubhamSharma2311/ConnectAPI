import React, { useEffect, useState } from "react";
import APIcard from "../components/APIcard";
import SearchBar from "../components/searchBar";

interface API {
  _id: string;
  name: string;
  description: string;
  pricing: string;
}

const APIList: React.FC = () => {
  const [apis, setApis] = useState<API[]>([]);
  const [query, setQuery] = useState(""); // State for search query

  useEffect(() => {
    const fetchAPIs = async () => {
      try {
        const response = await fetch(`/api/apis?search=${query}`);
        const data = await response.json();
        setApis(data.apis);
      } catch (error) {
        console.error("Error fetching APIs:", error);
      }
    };

    fetchAPIs();
  }, [query]); // Fetch APIs when `query` changes

  return (
    <div className="p-6">
      <SearchBar setQuery={setQuery} /> {/* Pass setQuery as a prop */}
      <h1 className="text-3xl font-bold text-center text-gray-800 mt-6">Explore APIs</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mt-6">
        {apis.map((api) => (
          <APIcard key={api._id} name={api.name} description={api.description} pricing={api.pricing} />
        ))}
      </div>
    </div>
  );
};

export default APIList;
